﻿namespace VFSBase.Persistence.Coding.General
{
    public enum StreamEncryptionType
    {
        None,
        MicrosoftAes,
        SelfMadeAes,
        SelfMadeCaesar,
        SelfMadeSimple
    }
}