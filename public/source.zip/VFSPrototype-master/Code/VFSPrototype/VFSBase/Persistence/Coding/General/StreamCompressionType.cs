﻿namespace VFSBase.Persistence.Coding.General
{
    public enum StreamCompressionType
    {
        None,
        MicrosoftDeflate,
        SelfMadeLz77
    }
}