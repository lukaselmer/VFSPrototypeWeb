namespace VFSBase.Persistence.Coding.SelfMadeAes
{
    /// <summary>
    /// The crypto direction
    /// </summary>
    internal enum CryptoDirection
    {
        Encrypt,
        Decrypt
    }
}