﻿using System;

namespace VFSBase.Interfaces
{
    public class FileSystemChangedEventArgs : EventArgs
    {
    }
}